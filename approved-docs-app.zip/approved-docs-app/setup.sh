#!/usr/bin/env sh
# Usage: ./setup.sh        (SDK 58)
#        ./setup.sh 57     (SDK 57, if that is what your Expo Go supports)
node scripts/setup.js "$1"
