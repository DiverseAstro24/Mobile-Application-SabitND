@echo off
REM Usage: setup.bat        (SDK 58)
REM        setup.bat 57     (SDK 57, if that is what your Expo Go supports)
node scripts\setup.js %1
pause
