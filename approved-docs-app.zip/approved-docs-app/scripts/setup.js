#!/usr/bin/env node
/**
 * Installs the app for a chosen Expo SDK, so it matches the Expo Go on your phone.
 *
 *   node scripts/setup.js        -> SDK 58 (default)
 *   node scripts/setup.js 57     -> SDK 57
 *
 * Expo Go only opens projects from the SDK it supports. If Expo Go says the project
 * is incompatible, run this again with the SDK number that message names.
 */
const { spawnSync } = require('child_process');
const fs = require('fs');

const DEFAULT_SDK = 58;
const sdk = parseInt(process.argv[2] || String(DEFAULT_SDK), 10);

if (!Number.isInteger(sdk) || sdk < 50 || sdk > 99) {
  console.error('Usage: node scripts/setup.js <sdk-number>   (for example 58 or 57)');
  process.exit(1);
}

const isWin = process.platform === 'win32';

function run(command, { optional = false } = {}) {
  console.log(`\n> ${command}`);
  const result = spawnSync(command, { stdio: 'inherit', shell: true });
  if (result.status !== 0) {
    if (optional) {
      console.warn('  (step reported problems, continuing)');
      return false;
    }
    console.error(`\nStep failed: ${command}`);
    console.error('Check your internet connection and that Node.js 20.19+ (or 22 LTS) is installed.');
    process.exit(result.status || 1);
  }
  return true;
}

console.log(`Setting up for Expo SDK ${sdk}...`);

// 1. Set the SDK, then let Expo choose matching versions of everything else.
run(`npm install expo@${sdk}`);
run(
  'npx expo install react react-dom react-native react-native-web ' +
    '@expo/metro-runtime expo-status-bar react-native-safe-area-context ' +
    'expo-document-picker expo-image-picker',
);
run('npx expo install --fix', { optional: true });

// 2. Local settings file for the model server address.
if (!fs.existsSync('.env') && fs.existsSync('.env.example')) {
  fs.copyFileSync('.env.example', '.env');
  console.log('\nCreated .env from .env.example');
}

// 3. Health check (informational).
run('npx expo-doctor', { optional: true });

console.log(`\nDone. Installed for Expo SDK ${sdk}.`);
console.log('Start the app with:  npx expo start');
console.log('Then scan the QR code with Expo Go, or press w to open it in your browser.');
