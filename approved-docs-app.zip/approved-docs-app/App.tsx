import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { errorMessage, getConfig } from './src/api';
import { AddScreen } from './src/screens/AddScreen';
import { BrowseScreen } from './src/screens/BrowseScreen';
import { SearchScreen } from './src/screens/SearchScreen';
import { AppConfig } from './src/types';
import { colors } from './src/theme';

type Tab = 'add' | 'search' | 'browse';

const TABS: { value: Tab; label: string }[] = [
  { value: 'add', label: 'Add' },
  { value: 'search', label: 'Search' },
  { value: 'browse', label: 'Browse' },
];

export default function App() {
  const [tab, setTab] = useState<Tab>('add');
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const connect = useCallback(() => {
    setServerError(null);
    getConfig()
      .then(setConfig)
      .catch((e) => {
        setConfig(null);
        setServerError(errorMessage(e));
      });
  }, []);

  useEffect(connect, [connect]);

  // Screens stay mounted so a half-finished upload is not lost when you switch tabs.
  const visible = (t: Tab) => (tab === t ? styles.flex : styles.hidden);

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.safe}>
        <StatusBar style="dark" />
        <View style={styles.header}>
          <Text style={styles.title}>Approved documents</Text>
          <Text style={styles.status}>
            {config
              ? `Sorting by ${config.classifier === 'rules-baseline' ? 'keyword baseline' : 'your model'}, stored on ${config.storage} server`
              : 'Not connected'}
          </Text>
        </View>

        {serverError && (
          <View style={styles.error}>
            <Text style={styles.errorText}>{serverError}</Text>
            <Pressable onPress={connect} accessibilityRole="button">
              <Text style={styles.retry}>Try again</Text>
            </Pressable>
          </View>
        )}

        <View style={visible('add')}>
          <AddScreen config={config} onSaved={() => setRefreshKey((k) => k + 1)} />
        </View>
        <View style={visible('search')}>
          <SearchScreen config={config} refreshKey={refreshKey} />
        </View>
        <View style={visible('browse')}>
          <BrowseScreen refreshKey={refreshKey} />
        </View>

        <View style={styles.tabBar}>
          {TABS.map((t) => {
            const active = t.value === tab;
            return (
              <Pressable
                key={t.value}
                onPress={() => setTab(t.value)}
                style={[styles.tab, active && styles.tabActive]}
                accessibilityRole="tab"
                accessibilityState={{ selected: active }}
              >
                <Text style={[styles.tabText, active && styles.tabTextActive]}>{t.label}</Text>
              </Pressable>
            );
          })}
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  hidden: { display: 'none' },
  safe: { flex: 1, backgroundColor: colors.paper },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 8 },
  title: { fontSize: 26, fontWeight: '800', color: colors.ink },
  status: { marginTop: 2, fontSize: 12, color: colors.muted },
  error: { marginHorizontal: 20, marginTop: 4, padding: 12, borderRadius: 8, backgroundColor: colors.dangerSoft },
  errorText: { color: colors.danger, fontSize: 14 },
  retry: { marginTop: 8, color: colors.danger, fontWeight: '700', fontSize: 14 },
  tabBar: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: colors.line, backgroundColor: colors.surface },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 14, borderTopWidth: 2, borderTopColor: 'transparent' },
  tabActive: { borderTopColor: colors.accent },
  tabText: { fontSize: 15, color: colors.muted, fontWeight: '600' },
  tabTextActive: { color: colors.accent },
});
