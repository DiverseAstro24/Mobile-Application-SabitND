import { Platform } from 'react-native';
import { CONFIG } from './config';
import { Analysis, AppConfig, ArchivedDoc, DocType, PickedFile, TreeRow } from './types';

async function request<T>(path: string, init: RequestInit = {}, timeoutMs = CONFIG.timeoutMs): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const headers: Record<string, string> = { ...(init.headers as Record<string, string>) };
  if (CONFIG.apiKey) headers['X-API-Key'] = CONFIG.apiKey;

  try {
    const response = await fetch(`${CONFIG.apiUrl}${path}`, { ...init, headers, signal: controller.signal });
    if (!response.ok) {
      let detail = '';
      try {
        const body = await response.json();
        if (typeof body?.detail === 'string') detail = body.detail;
      } catch {
        // response had no JSON body
      }
      throw new Error(detail || `The server returned status ${response.status}.`);
    }
    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error('The server took too long to respond. Check that it is running.');
    }
    if (error instanceof TypeError) {
      throw new Error(`Could not reach ${CONFIG.apiUrl}. Check that the server is running and the API URL is right.`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

export const getConfig = () => request<AppConfig>('/config');
export const getTree = () => request<TreeRow[]>('/tree');

export async function analyze(files: PickedFile[]): Promise<Analysis> {
  const form = new FormData();
  for (const file of files) {
    if (Platform.OS === 'web') {
      const blob = await (await fetch(file.uri)).blob();
      form.append('files', blob, file.name);
    } else {
      form.append('files', { uri: file.uri, name: file.name, type: file.mimeType } as any);
    }
  }
  return request<Analysis>('/analyze', { method: 'POST', body: form }, CONFIG.uploadTimeoutMs);
}

export interface SavePayload {
  upload_id: string;
  doc_type: DocType;
  title: string;
  reference_no: string | null;
  approved_date: string;
  offices: string[];
  people: string[];
  approved_by_president: boolean;
}

export const saveDocument = (payload: SavePayload) =>
  request<ArchivedDoc>('/documents', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

export interface SearchParams {
  q?: string;
  year?: number | null;
  month?: number | null;
  doc_type?: DocType | null;
  office?: string | null;
  limit?: number;
}

export function searchDocuments(params: SearchParams) {
  const parts: string[] = [];
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      parts.push(`${key}=${encodeURIComponent(String(value))}`);
    }
  });
  return request<ArchivedDoc[]>(`/documents/search${parts.length ? '?' + parts.join('&') : ''}`);
}

export function fileUrl(id: string): string {
  const key = CONFIG.apiKey ? `?key=${encodeURIComponent(CONFIG.apiKey)}` : '';
  return `${CONFIG.apiUrl}/files/${id}${key}`;
}

export const errorMessage = (e: unknown) => (e instanceof Error ? e.message : 'Something went wrong. Try again.');
