import { Platform } from 'react-native';

// Android emulators reach the host computer at 10.0.2.2; iOS simulators and browsers use localhost.
// On a physical phone, set EXPO_PUBLIC_API_URL in the .env file to your computer's address,
// e.g. EXPO_PUBLIC_API_URL=http://192.168.1.20:8000
const defaultHost = Platform.OS === 'android' ? '10.0.2.2' : 'localhost';

export const CONFIG = {
  apiUrl: process.env.EXPO_PUBLIC_API_URL ?? `http://${defaultHost}:8000`,
  // Must match ARCHIVE_API_KEY on the server, if you set one there.
  apiKey: process.env.EXPO_PUBLIC_API_KEY ?? '',
  timeoutMs: 15000,
  uploadTimeoutMs: 180000, // scanned pages can take a while to read
  // Suggestions below this confidence are marked "please check the type".
  confidenceThreshold: 0.6,
};
