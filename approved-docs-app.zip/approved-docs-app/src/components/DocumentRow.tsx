import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ArchivedDoc, typeLabel } from '../types';
import { colors } from '../theme';

interface Props {
  doc: ArchivedDoc;
  onPress: (doc: ArchivedDoc) => void;
}

export function DocumentRow({ doc, onPress }: Props) {
  return (
    <Pressable
      onPress={() => onPress(doc)}
      style={({ pressed }) => [styles.row, pressed && { opacity: 0.6 }]}
      accessibilityRole="button"
    >
      <Text style={styles.title} numberOfLines={2}>
        {doc.title}
      </Text>
      <Text style={styles.meta}>
        {doc.approved_date}, {typeLabel(doc.doc_type)}
      </Text>
      {doc.offices.length > 0 && (
        <Text style={styles.offices} numberOfLines={1}>
          {doc.offices.join(', ')}
        </Text>
      )}
      {doc.snippet ? (
        <View style={styles.snippetBox}>
          <Text style={styles.snippet} numberOfLines={2}>
            {doc.snippet.replace(/\s+/g, ' ')}
          </Text>
        </View>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { paddingVertical: 14, borderTopWidth: 1, borderTopColor: colors.line },
  title: { fontSize: 16, fontWeight: '600', color: colors.ink },
  meta: { marginTop: 3, fontSize: 13, color: colors.accent, fontWeight: '600' },
  offices: { marginTop: 2, fontSize: 13, color: colors.muted },
  snippetBox: { marginTop: 6, padding: 8, borderRadius: 6, backgroundColor: colors.paper },
  snippet: { fontSize: 12, color: colors.muted },
});
