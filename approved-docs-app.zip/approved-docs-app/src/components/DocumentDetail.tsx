import React from 'react';
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { fileUrl } from '../api';
import { ArchivedDoc, MONTHS, typeLabel } from '../types';
import { colors } from '../theme';

interface Props {
  doc: ArchivedDoc;
  onBack: () => void;
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <Text style={styles.fieldValue}>{value}</Text>
    </View>
  );
}

export function DocumentDetail({ doc, onBack }: Props) {
  return (
    <ScrollView contentContainerStyle={styles.content}>
      <Pressable onPress={onBack} accessibilityRole="button">
        <Text style={styles.back}>Back to list</Text>
      </Pressable>
      <Text style={styles.title}>{doc.title}</Text>

      <Pressable onPress={() => Linking.openURL(fileUrl(doc.id))} style={styles.button} accessibilityRole="button">
        <Text style={styles.buttonText}>Open PDF</Text>
      </Pressable>

      <View style={styles.card}>
        <Field label="Approved on" value={`${MONTHS[doc.month - 1]} ${doc.approved_date.slice(8)}, ${doc.year}`} />
        <Field label="Type" value={typeLabel(doc.doc_type)} />
        {doc.reference_no ? <Field label="Reference" value={doc.reference_no} /> : null}
        <Field label="Offices involved" value={doc.offices.length ? doc.offices.join('\n') : 'None recorded'} />
        <Field label="People involved" value={doc.people.length ? doc.people.join('\n') : 'None recorded'} />
        <Field label="Archive location" value={`Archive/${doc.stored_path}`} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 40 },
  back: { fontSize: 15, color: colors.accent, fontWeight: '600', marginBottom: 14 },
  title: { fontSize: 22, fontWeight: '700', color: colors.ink },
  button: {
    marginTop: 16,
    height: 46,
    borderRadius: 12,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },
  card: {
    marginTop: 18,
    backgroundColor: colors.surface,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.line,
    padding: 16,
  },
  field: { paddingVertical: 8 },
  fieldLabel: { fontSize: 12, color: colors.muted, fontWeight: '600', textTransform: 'uppercase' },
  fieldValue: { marginTop: 2, fontSize: 15, color: colors.ink },
});
