import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { errorMessage, getTree, searchDocuments } from '../api';
import { DocumentDetail } from '../components/DocumentDetail';
import { DocumentRow } from '../components/DocumentRow';
import { colors } from '../theme';
import { ArchivedDoc, DocType, TreeRow, monthFolder, typeLabel } from '../types';

interface Props {
  refreshKey: number;
}

function FolderRow({ label, count, onPress }: { label: string; count: number; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.folder, pressed && { opacity: 0.6 }]} accessibilityRole="button">
      <Text style={styles.folderName}>{label}</Text>
      <Text style={styles.folderCount}>
        {count} file{count === 1 ? '' : 's'}  ›
      </Text>
    </Pressable>
  );
}

const sum = (rows: TreeRow[]) => rows.reduce((total, r) => total + r.count, 0);

export function BrowseScreen({ refreshKey }: Props) {
  const [rows, setRows] = useState<TreeRow[]>([]);
  const [year, setYear] = useState<number | null>(null);
  const [month, setMonth] = useState<number | null>(null);
  const [type, setType] = useState<DocType | null>(null);
  const [docs, setDocs] = useState<ArchivedDoc[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<ArchivedDoc | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    getTree()
      .then(setRows)
      .catch((e) => setError(errorMessage(e)))
      .finally(() => setLoading(false));
  }, [refreshKey]);

  useEffect(() => {
    if (year === null || month === null || type === null) {
      setDocs([]);
      return;
    }
    setLoading(true);
    searchDocuments({ year, month, doc_type: type, limit: 200 })
      .then(setDocs)
      .catch((e) => setError(errorMessage(e)))
      .finally(() => setLoading(false));
  }, [year, month, type, refreshKey]);

  if (selected) return <DocumentDetail doc={selected} onBack={() => setSelected(null)} />;

  // Breadcrumb: Archive > 2026 > 11-November > Procurement
  const crumbs: { label: string; go: () => void }[] = [
    { label: 'Archive', go: () => { setYear(null); setMonth(null); setType(null); } },
  ];
  if (year !== null) crumbs.push({ label: String(year), go: () => { setMonth(null); setType(null); } });
  if (month !== null) crumbs.push({ label: monthFolder(month), go: () => setType(null) });
  if (type !== null) crumbs.push({ label: typeLabel(type), go: () => undefined });

  let list: React.ReactNode;
  if (year === null) {
    const years = Array.from(new Set(rows.map((r) => r.year))).sort((a, b) => b - a);
    list = years.map((y) => <FolderRow key={y} label={String(y)} count={sum(rows.filter((r) => r.year === y))} onPress={() => setYear(y)} />);
  } else if (month === null) {
    const months = Array.from(new Set(rows.filter((r) => r.year === year).map((r) => r.month))).sort((a, b) => b - a);
    list = months.map((m) => (
      <FolderRow key={m} label={monthFolder(m)} count={sum(rows.filter((r) => r.year === year && r.month === m))} onPress={() => setMonth(m)} />
    ));
  } else if (type === null) {
    const here = rows.filter((r) => r.year === year && r.month === month);
    list = here.map((r) => <FolderRow key={r.doc_type} label={typeLabel(r.doc_type)} count={r.count} onPress={() => setType(r.doc_type)} />);
  } else {
    list = docs.map((d) => <DocumentRow key={d.id} doc={d} onPress={setSelected} />);
  }

  return (
    <ScrollView contentContainerStyle={styles.content}>
      <View style={styles.crumbs}>
        {crumbs.map((c, i) => (
          <Pressable key={c.label + i} onPress={c.go} accessibilityRole="button">
            <Text style={[styles.crumb, i === crumbs.length - 1 && styles.crumbLast]}>
              {c.label}
              {i < crumbs.length - 1 ? '  /  ' : ''}
            </Text>
          </Pressable>
        ))}
      </View>

      {loading && <ActivityIndicator color={colors.accent} style={styles.spinner} />}
      {error && (
        <View style={styles.error}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}
      {!loading && !error && rows.length === 0 && <Text style={styles.empty}>The archive is empty. Add a document on the first tab.</Text>}
      {list}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 48 },
  crumbs: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 },
  crumb: { fontSize: 14, color: colors.accent, fontWeight: '600' },
  crumbLast: { color: colors.ink },
  spinner: { marginVertical: 12 },
  empty: { marginTop: 12, fontSize: 14, color: colors.muted },
  folder: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: colors.line,
  },
  folderName: { fontSize: 17, fontWeight: '600', color: colors.ink },
  folderCount: { fontSize: 14, color: colors.muted },
  error: { marginTop: 8, padding: 12, borderRadius: 8, backgroundColor: colors.dangerSoft },
  errorText: { color: colors.danger, fontSize: 14 },
});
