import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { errorMessage, getTree, searchDocuments } from '../api';
import { Chip } from '../components/Chip';
import { DocumentDetail } from '../components/DocumentDetail';
import { DocumentRow } from '../components/DocumentRow';
import { colors } from '../theme';
import { AppConfig, ArchivedDoc, DOC_TYPES, DocType } from '../types';

interface Props {
  config: AppConfig | null;
  refreshKey: number;
}

export function SearchScreen({ config, refreshKey }: Props) {
  const [q, setQ] = useState('');
  const [type, setType] = useState<DocType | null>(null);
  const [year, setYear] = useState<number | null>(null);
  const [office, setOffice] = useState<string | null>(null);
  const [years, setYears] = useState<number[]>([]);
  const [results, setResults] = useState<ArchivedDoc[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<ArchivedDoc | null>(null);

  useEffect(() => {
    getTree()
      .then((rows) => setYears(Array.from(new Set(rows.map((r) => r.year))).sort((a, b) => b - a)))
      .catch(() => setYears([]));
  }, [refreshKey]);

  useEffect(() => {
    let cancelled = false;
    const timer = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const found = await searchDocuments({ q, doc_type: type, year, office });
        if (!cancelled) setResults(found);
      } catch (e) {
        if (!cancelled) setError(errorMessage(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [q, type, year, office, refreshKey]);

  if (selected) return <DocumentDetail doc={selected} onBack={() => setSelected(null)} />;

  const filtering = q.trim() !== '' || type !== null || year !== null || office !== null;

  return (
    <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <TextInput
        style={styles.input}
        value={q}
        onChangeText={setQ}
        placeholder="Search title, office, name or words in the document"
        placeholderTextColor={colors.muted}
        autoCorrect={false}
        returnKeyType="search"
      />

      <Text style={styles.label}>Type</Text>
      <View style={styles.chips}>
        <Chip label="All" active={type === null} onPress={() => setType(null)} />
        {DOC_TYPES.map((t) => (
          <Chip key={t.value} label={t.label} active={type === t.value} onPress={() => setType(type === t.value ? null : t.value)} />
        ))}
      </View>

      {years.length > 0 && (
        <>
          <Text style={styles.label}>Year approved</Text>
          <View style={styles.chips}>
            <Chip label="Any" active={year === null} onPress={() => setYear(null)} />
            {years.map((y) => (
              <Chip key={y} label={String(y)} active={year === y} onPress={() => setYear(year === y ? null : y)} />
            ))}
          </View>
        </>
      )}

      {config && config.offices.length > 0 && (
        <>
          <Text style={styles.label}>Office involved</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
            <Chip label="Any" active={office === null} onPress={() => setOffice(null)} />
            {config.offices.map((o) => (
              <Chip key={o} label={o} active={office === o} onPress={() => setOffice(office === o ? null : o)} />
            ))}
          </ScrollView>
        </>
      )}

      <Text style={styles.heading}>{filtering ? `Results (${results.length})` : 'Recently approved'}</Text>
      {loading && <ActivityIndicator color={colors.accent} style={styles.spinner} />}
      {error && (
        <View style={styles.error}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}
      {!loading && !error && results.length === 0 && (
        <Text style={styles.empty}>{filtering ? 'No documents match. Try fewer words or clear a filter.' : 'Nothing archived yet.'}</Text>
      )}
      {results.map((doc) => (
        <DocumentRow key={doc.id} doc={doc} onPress={setSelected} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 48 },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.ink,
  },
  label: { marginTop: 16, marginBottom: 8, fontSize: 13, fontWeight: '600', color: colors.muted },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chipsRow: { flexDirection: 'row', gap: 8, paddingRight: 20 },
  heading: { marginTop: 24, marginBottom: 4, fontSize: 16, fontWeight: '700', color: colors.ink },
  spinner: { marginVertical: 12 },
  empty: { marginTop: 8, fontSize: 14, color: colors.muted },
  error: { marginTop: 8, padding: 12, borderRadius: 8, backgroundColor: colors.dangerSoft },
  errorText: { color: colors.danger, fontSize: 14 },
});
