import React, { useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { analyze, errorMessage, saveDocument } from '../api';
import { CONFIG } from '../config';
import { Chip } from '../components/Chip';
import { colors } from '../theme';
import { Analysis, AppConfig, ArchivedDoc, DOC_TYPES, DocType, PickedFile, typeLabel } from '../types';

interface Props {
  config: AppConfig | null;
  onSaved: () => void;
}

type Phase = 'pick' | 'analyzing' | 'review' | 'saving' | 'saved';

function isValidDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d;
}

function todayIso(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function AddScreen({ config, onSaved }: Props) {
  const [phase, setPhase] = useState<Phase>('pick');
  const [files, setFiles] = useState<PickedFile[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [docType, setDocType] = useState<DocType>('general_internal');
  const [title, setTitle] = useState('');
  const [reference, setReference] = useState('');
  const [date, setDate] = useState('');
  const [offices, setOffices] = useState<string[]>([]);
  const [people, setPeople] = useState('');
  const [approved, setApproved] = useState(false);
  const [saved, setSaved] = useState<ArchivedDoc | null>(null);

  // ---------------------------------------------------------------- picking files
  async function pickPdf() {
    setError(null);
    try {
      const res = await DocumentPicker.getDocumentAsync({ type: 'application/pdf', copyToCacheDirectory: true });
      if (res.canceled || !res.assets?.length) return;
      const a = res.assets[0];
      setFiles([{ uri: a.uri, name: a.name || 'document.pdf', mimeType: a.mimeType || 'application/pdf' }]);
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  function addImages(assets: ImagePicker.ImagePickerAsset[]) {
    setFiles((prev) => {
      const base = prev.filter((f) => f.mimeType.startsWith('image/')); // a PDF and photos cannot be mixed
      const added = assets.map((a, i) => {
        const mime = a.mimeType ?? 'image/jpeg';
        const ext = mime === 'image/jpeg' ? 'jpg' : mime.split('/')[1] || 'jpg';
        return { uri: a.uri, name: `page-${base.length + i + 1}.${ext}`, mimeType: mime };
      });
      return [...base, ...added];
    });
  }

  async function takePhoto() {
    setError(null);
    try {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) {
        setError('Camera permission is needed to scan documents. You can allow it in your phone settings.');
        return;
      }
      const res = await ImagePicker.launchCameraAsync({ quality: 0.8 });
      if (!res.canceled) addImages(res.assets);
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  async function pickPhotos() {
    setError(null);
    try {
      const res = await ImagePicker.launchImageLibraryAsync({ allowsMultipleSelection: true, quality: 0.8 });
      if (!res.canceled) addImages(res.assets);
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  // ---------------------------------------------------------------- analyze and save
  async function runAnalyze() {
    setPhase('analyzing');
    setError(null);
    try {
      const result = await analyze(files);
      setAnalysis(result);
      setDocType(result.doc_type);
      setTitle(result.title);
      setReference(result.reference_no ?? '');
      setDate(result.approved_date ?? '');
      setOffices(result.offices);
      setPeople(result.people.join(', '));
      setApproved(false);
      setPhase('review');
    } catch (e) {
      setError(errorMessage(e));
      setPhase('pick');
    }
  }

  const dateOk = isValidDate(date);
  const canSave = phase === 'review' && title.trim().length > 0 && dateOk && approved;

  async function save() {
    if (!analysis || !canSave) return;
    setPhase('saving');
    setError(null);
    try {
      const doc = await saveDocument({
        upload_id: analysis.upload_id,
        doc_type: docType,
        title: title.trim(),
        reference_no: reference.trim() || null,
        approved_date: date,
        offices,
        people: people.split(/[,;\n]/).map((s) => s.trim()).filter(Boolean),
        approved_by_president: approved,
      });
      setSaved(doc);
      setPhase('saved');
      onSaved();
    } catch (e) {
      setError(errorMessage(e));
      setPhase('review');
    }
  }

  function reset() {
    setPhase('pick');
    setFiles([]);
    setAnalysis(null);
    setSaved(null);
    setError(null);
  }

  function toggleOffice(name: string) {
    setOffices((prev) => (prev.includes(name) ? prev.filter((o) => o !== name) : [...prev, name]));
  }

  const officeOptions = Array.from(new Set([...(config?.offices ?? []), ...offices]));
  const lowConfidence = analysis ? analysis.confidence < CONFIG.confidenceThreshold : false;
  const usedBaseline = analysis?.classifier.startsWith('rules') ?? false;

  // ---------------------------------------------------------------- screens
  let body: React.ReactNode;

  if (phase === 'analyzing' || phase === 'saving') {
    body = (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.centerText}>
          {phase === 'analyzing' ? 'Reading the document...' : 'Filing the document...'}
        </Text>
      </View>
    );
  } else if (phase === 'saved' && saved) {
    body = (
      <View>
        <View style={[styles.banner, styles.bannerOk]}>
          <Text style={[styles.bannerText, { color: colors.accent }]}>Saved to the archive.</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.docTitle}>{saved.title}</Text>
          <Text style={styles.hint}>Filed in</Text>
          <Text style={styles.path}>Archive/{saved.stored_path}</Text>
        </View>
        <Pressable onPress={reset} style={styles.button} accessibilityRole="button">
          <Text style={styles.buttonText}>Add another document</Text>
        </Pressable>
      </View>
    );
  } else if (phase === 'review' && analysis) {
    body = (
      <View>
        <Text style={styles.sectionTitle}>Check the details</Text>
        <Text style={styles.hint}>
          Read {analysis.pages} page{analysis.pages === 1 ? '' : 's'}, {analysis.text_chars} characters of text. Everything below is a
          suggestion, so please correct anything that is wrong.
        </Text>

        {analysis.warnings.map((w) => (
          <View key={w} style={[styles.banner, styles.bannerWarn]}>
            <Text style={[styles.bannerText, { color: colors.warn }]}>{w}</Text>
          </View>
        ))}

        <Text style={styles.label}>Document type</Text>
        <View style={styles.chips}>
          {DOC_TYPES.map((t) => (
            <Chip key={t.value} label={t.label} active={t.value === docType} onPress={() => setDocType(t.value)} />
          ))}
        </View>
        <Text style={styles.hint}>
          Suggested: {typeLabel(analysis.doc_type)} ({Math.round(analysis.confidence * 100)}% sure, by{' '}
          {usedBaseline ? 'the keyword baseline' : 'your model'}).
          {lowConfidence ? ' Not sure about this one, please check the type.' : ''}
        </Text>

        <Text style={styles.label}>Title</Text>
        <TextInput style={styles.input} value={title} onChangeText={setTitle} placeholder="What is this document?" placeholderTextColor={colors.muted} />

        <Text style={styles.label}>Reference number (optional)</Text>
        <TextInput style={styles.input} value={reference} onChangeText={setReference} placeholder="Office Order No. 25, s. 2026" placeholderTextColor={colors.muted} />

        <Text style={styles.label}>Date approved (YYYY-MM-DD)</Text>
        <View style={styles.dateRow}>
          <TextInput
            style={[styles.input, styles.dateInput, date !== '' && !dateOk && styles.inputBad]}
            value={date}
            onChangeText={setDate}
            placeholder="2026-11-05"
            placeholderTextColor={colors.muted}
            autoCapitalize="none"
            keyboardType="numbers-and-punctuation"
          />
          <Chip label="Today" onPress={() => setDate(todayIso())} />
        </View>
        {!analysis.approved_date && <Text style={styles.hintWarn}>No date was found in the document. Please enter it.</Text>}
        {date !== '' && !dateOk && <Text style={styles.hintWarn}>Use the form 2026-11-05.</Text>}

        <Text style={styles.label}>Offices involved</Text>
        <View style={styles.chips}>
          {officeOptions.map((o) => (
            <Chip key={o} label={o} active={offices.includes(o)} onPress={() => toggleOffice(o)} />
          ))}
        </View>

        <Text style={styles.label}>People involved</Text>
        <TextInput
          style={[styles.input, styles.multiline]}
          value={people}
          onChangeText={setPeople}
          placeholder="Separate names with commas"
          placeholderTextColor={colors.muted}
          multiline
          textAlignVertical="top"
        />

        <View style={styles.confirmRow}>
          <Switch value={approved} onValueChange={setApproved} trackColor={{ true: colors.accent }} />
          <Text style={styles.confirmText}>This document is approved and signed by the President.</Text>
        </View>

        <Pressable onPress={save} disabled={!canSave} style={[styles.button, !canSave && styles.buttonDisabled]} accessibilityRole="button">
          <Text style={styles.buttonText}>Save to archive</Text>
        </Pressable>
        <Pressable onPress={reset} style={styles.linkButton} accessibilityRole="button">
          <Text style={styles.linkText}>Start over</Text>
        </Pressable>
      </View>
    );
  } else {
    body = (
      <View>
        <Text style={styles.sectionTitle}>Add an approved document</Text>
        <Text style={styles.hint}>
          Choose the signed PDF, or scan the signed pages with the camera. The app reads it, suggests where it belongs, and files it by year,
          month and type.
        </Text>
        {config && !config.ocr && (
          <View style={[styles.banner, styles.bannerWarn]}>
            <Text style={[styles.bannerText, { color: colors.warn }]}>
              Text can be read from digital PDFs now. Photos and scanned PDFs need OCR installed on the server (see the README).
            </Text>
          </View>
        )}

        <Pressable onPress={pickPdf} style={styles.button} accessibilityRole="button">
          <Text style={styles.buttonText}>Choose a PDF</Text>
        </Pressable>
        <View style={styles.twoButtons}>
          <Pressable onPress={takePhoto} style={[styles.buttonOutline, styles.flex]} accessibilityRole="button">
            <Text style={styles.buttonOutlineText}>Scan with camera</Text>
          </Pressable>
          <Pressable onPress={pickPhotos} style={[styles.buttonOutline, styles.flex]} accessibilityRole="button">
            <Text style={styles.buttonOutlineText}>Choose photos</Text>
          </Pressable>
        </View>

        {files.length > 0 && (
          <View style={styles.card}>
            <Text style={styles.label}>Ready to read</Text>
            {files.map((f, i) => (
              <View key={f.uri + i} style={styles.fileRow}>
                <Text style={styles.fileName} numberOfLines={1}>
                  {f.name}
                </Text>
                <Pressable onPress={() => setFiles((prev) => prev.filter((_, idx) => idx !== i))} accessibilityRole="button">
                  <Text style={styles.removeText}>Remove</Text>
                </Pressable>
              </View>
            ))}
            <Text style={styles.hint}>Scanning several pages? Add each page, in order.</Text>
            <Pressable onPress={runAnalyze} style={styles.button} accessibilityRole="button">
              <Text style={styles.buttonText}>Read document</Text>
            </Pressable>
          </View>
        )}
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {error && (
          <View style={[styles.banner, styles.bannerBad]}>
            <Text style={[styles.bannerText, { color: colors.danger }]}>{error}</Text>
          </View>
        )}
        {body}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: { padding: 20, paddingBottom: 48 },
  center: { paddingVertical: 80, alignItems: 'center' },
  centerText: { marginTop: 14, fontSize: 15, color: colors.muted },
  sectionTitle: { fontSize: 20, fontWeight: '700', color: colors.ink, marginBottom: 6 },
  hint: { marginTop: 6, fontSize: 13, color: colors.muted, lineHeight: 18 },
  hintWarn: { marginTop: 6, fontSize: 13, color: colors.warn },
  label: { marginTop: 18, marginBottom: 8, fontSize: 14, fontWeight: '600', color: colors.ink },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.ink,
  },
  inputBad: { borderColor: colors.danger },
  multiline: { minHeight: 70 },
  dateRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  dateInput: { flex: 1 },
  confirmRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 22, padding: 12, borderRadius: 10, backgroundColor: colors.accentSoft },
  confirmText: { flex: 1, fontSize: 14, color: colors.ink, fontWeight: '600' },
  button: {
    marginTop: 16,
    height: 50,
    borderRadius: 12,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonDisabled: { opacity: 0.4 },
  buttonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  twoButtons: { flexDirection: 'row', gap: 10, marginTop: 10 },
  buttonOutline: {
    height: 46,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonOutlineText: { color: colors.accent, fontSize: 14, fontWeight: '700' },
  linkButton: { marginTop: 14, alignItems: 'center', padding: 8 },
  linkText: { color: colors.muted, fontSize: 14 },
  card: {
    marginTop: 18,
    backgroundColor: colors.surface,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.line,
    padding: 16,
  },
  docTitle: { fontSize: 17, fontWeight: '700', color: colors.ink, marginBottom: 6 },
  path: { marginTop: 2, fontSize: 13, color: colors.accent, fontWeight: '600' },
  fileRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 6 },
  fileName: { flex: 1, fontSize: 14, color: colors.ink, marginRight: 12 },
  removeText: { fontSize: 13, color: colors.danger },
  banner: { marginTop: 12, padding: 12, borderRadius: 8 },
  bannerOk: { backgroundColor: colors.accentSoft },
  bannerWarn: { backgroundColor: colors.warnSoft },
  bannerBad: { backgroundColor: colors.dangerSoft, marginTop: 0, marginBottom: 12 },
  bannerText: { fontSize: 14, fontWeight: '600' },
});
