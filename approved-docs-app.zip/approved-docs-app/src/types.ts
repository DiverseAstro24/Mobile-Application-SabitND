export type DocType = 'procurement' | 'financial' | 'general_internal' | 'general_external';

export const DOC_TYPES: { value: DocType; label: string }[] = [
  { value: 'procurement', label: 'Procurement' },
  { value: 'financial', label: 'Financial' },
  { value: 'general_internal', label: 'General (internal)' },
  { value: 'general_external', label: 'General (external)' },
];

export const typeLabel = (value: string) => DOC_TYPES.find((t) => t.value === value)?.label ?? value;

export const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];
// Same naming as the folders on the server: 11-November
export const monthFolder = (month: number) => `${String(month).padStart(2, '0')}-${MONTHS[month - 1]}`;

export interface AppConfig {
  offices: string[];
  classifier: string; // "rules-baseline" or "model:<id>"
  storage: string; // "local", later "s3" or "gdrive"
  ocr: boolean;
}

export interface Analysis {
  upload_id: string;
  classifier: string;
  doc_type: DocType;
  confidence: number;
  scores: Record<DocType, number>;
  approved_date: string | null;
  title: string;
  reference_no: string | null;
  offices: string[];
  people: string[];
  pages: number;
  text_chars: number;
  warnings: string[];
}

export interface ArchivedDoc {
  id: string;
  title: string;
  reference_no: string | null;
  doc_type: DocType;
  approved_date: string;
  year: number;
  month: number;
  offices: string[];
  people: string[];
  stored_path: string;
  snippet?: string;
}

export interface TreeRow {
  year: number;
  month: number;
  doc_type: DocType;
  count: number;
}

export interface PickedFile {
  uri: string;
  name: string;
  mimeType: string;
}
