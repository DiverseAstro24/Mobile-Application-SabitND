export const colors = {
  paper: '#F3F5F7',
  surface: '#FFFFFF',
  ink: '#18222D',
  muted: '#5E6B78',
  line: '#D9DEE3',
  accent: '#0B6E72',
  accentSoft: '#DCEFF0',
  warn: '#9A5B00',
  warnSoft: '#FBEBCB',
  danger: '#A12D2D',
  dangerSoft: '#F7DCDC',
};
